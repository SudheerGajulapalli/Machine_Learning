import math

text1 = "Name\tAge\tCountry\tCity"         # Using the tab sequence

text2 = "Asabeneh\t250\tFinland\tHelsinki"   # Using the tab sequence
print(text1)
print(text2)

  